// js/script.js - Versão Definitiva com Firebase e Chat Corrigido

const db = firebase.database();

window.accounts = [
    { id: '1', name: 'Supermercado Bom Preço', type: 'donor', email: 'contato@bompreco.com', roleLabel: 'Doador' },
    { id: '2', name: 'Padaria Pão Dourado', type: 'donor', email: 'contato@paodourado.com', roleLabel: 'Doador' },
    { id: '3', name: 'Igreja Batista Esperança', type: 'institution', email: 'igreja@esperanca.org', roleLabel: 'Instituição' }
];

window.currentAccount = window.accounts[0];
window.donations = []; 
let currentChatItemId = null; 

window.switchAuthTab = function(tab) {
    const tabLogin = document.getElementById('tab-login');
    const tabRegister = document.getElementById('tab-register');
    const formLogin = document.getElementById('form-login');
    const formRegister = document.getElementById('form-register');

    if (tab === 'login') {
        if (tabLogin) tabLogin.className = "flex-1 py-2 text-xs font-bold rounded-lg bg-white text-slate-800 shadow-sm transition cursor-pointer";
        if (tabRegister) tabRegister.className = "flex-1 py-2 text-xs font-bold rounded-lg text-slate-500 transition cursor-pointer";
        if (formLogin) formLogin.classList.remove('hidden');
        if (formRegister) formRegister.classList.add('hidden');
    } else {
        if (tabRegister) tabRegister.className = "flex-1 py-2 text-xs font-bold rounded-lg bg-white text-slate-800 shadow-sm transition cursor-pointer";
        if (tabLogin) tabLogin.className = "flex-1 py-2 text-xs font-bold rounded-lg text-slate-500 transition cursor-pointer";
        if (formRegister) formRegister.classList.remove('hidden');
        if (formLogin) formLogin.classList.add('hidden');
    }
};

window.handleLogin = function(e) {
    if (e) e.preventDefault();
    const emailInput = document.getElementById('login-email');
    const email = emailInput ? emailInput.value : 'contato@bompreco.com';
    
    let found = window.accounts.find(acc => acc.email === email);
    if (found) {
        window.currentAccount = found;
    } else {
        window.currentAccount = { id: '99', name: 'Supermercado Bom Preço', type: 'donor', email: email, roleLabel: 'Doador' };
    }
    window.enterApp();
};

window.handleRegister = function(e) {
    if (e) e.preventDefault();
    const nameInput = document.getElementById('reg-name');
    const typeInput = document.getElementById('reg-type');
    const emailInput = document.getElementById('reg-email');

    const name = (nameInput && nameInput.value) ? nameInput.value : 'Nova Loja';
    const type = (typeInput && typeInput.value) ? typeInput.value : 'donor';
    const email = (emailInput && emailInput.value) ? emailInput.value : 'loja@email.com';
    const roleLabel = type === 'donor' ? 'Doador' : 'Instituição';

    const newAcc = { id: String(window.accounts.length + 1), name, type, email, roleLabel };
    window.accounts.push(newAcc);
    window.currentAccount = newAcc;

    const switcher = document.getElementById('account-switcher');
    if (switcher) {
        const opt = document.createElement('option');
        opt.value = newAcc.id;
        opt.textContent = `${newAcc.name} (${roleLabel})`;
        switcher.appendChild(opt);
        switcher.value = newAcc.id;
    }

    window.enterApp();
};

window.enterApp = function() {
    const authScreen = document.getElementById('auth-screen');
    const appScreen = document.getElementById('app-screen');

    if (authScreen) authScreen.classList.add('hidden');
    if (appScreen) appScreen.classList.remove('hidden');
    
    window.updateDashboardUI();
    initFirebaseDonations();
};

window.logout = function() {
    const authScreen = document.getElementById('auth-screen');
    const appScreen = document.getElementById('app-screen');

    if (appScreen) appScreen.classList.add('hidden');
    if (authScreen) authScreen.classList.remove('hidden');
};

window.switchAccount = function(accountId) {
    const found = window.accounts.find(acc => acc.id === accountId);
    if (found) {
        window.currentAccount = found;
        window.updateDashboardUI();
        window.renderDonations();
    }
};

window.updateDashboardUI = function() {
    const welcomeTitle = document.getElementById('welcome-title');
    const accountBadge = document.getElementById('account-badge');
    const accountEmail = document.getElementById('account-email');
    const donorActionView = document.getElementById('donor-action-view');
    const sectionListTitle = document.getElementById('section-list-title');

    if (welcomeTitle) welcomeTitle.textContent = `Olá, ${window.currentAccount.name}! 👋`;
    if (accountBadge) accountBadge.textContent = window.currentAccount.roleLabel;
    if (accountEmail) accountEmail.textContent = window.currentAccount.email;

    if (window.currentAccount.type === 'donor') {
        if (donorActionView) donorActionView.classList.remove('hidden');
        if (sectionListTitle) sectionListTitle.innerHTML = `<i data-lucide="list" class="w-5 h-5 text-emerald-600"></i> Minhas Doações Cadastradas`;
    } else {
        if (donorActionView) donorActionView.classList.add('hidden');
        if (sectionListTitle) sectionListTitle.innerHTML = `<i data-lucide="shopping-bag" class="w-5 h-5 text-emerald-600"></i> Alimentos Disponíveis para Resgate`;
    }
    if (window.lucide) window.lucide.createIcons();
};

function initFirebaseDonations() {
    db.ref('items').on('value', (snapshot) => {
        const data = snapshot.val();
        window.donations = [];
        if (data) {
            Object.keys(data).forEach(key => {
                window.donations.push({
                    firebaseKey: key,
                    ...data[key]
                });
            });
        }
        window.renderDonations();
    });
}

window.renderDonations = function(filterText = '') {
    const grid = document.getElementById('donations-grid');
    if (!grid) return;

    grid.innerHTML = '';

    let listToRender = window.donations;
    if (window.currentAccount.type === 'donor') {
        listToRender = window.donations.filter(item => item.donor === window.currentAccount.name);
    }

    const filtered = listToRender.filter(item => 
        (item.title && item.title.toLowerCase().includes(filterText.toLowerCase())) ||
        (item.donor && item.donor.toLowerCase().includes(filterText.toLowerCase()))
    );

    const statDonations = document.getElementById('stat-donations');
    if (statDonations) statDonations.textContent = filtered.length;

    if (filtered.length === 0) {
        grid.innerHTML = `
            <div class="col-span-full bg-white rounded-2xl p-8 text-center border border-slate-100 text-slate-400">
                <i data-lucide="folder-search" class="w-10 h-10 mx-auto mb-2 stroke-1"></i>
                <p class="text-sm font-medium">Nenhum registro encontrado na nuvem.</p>
            </div>
        `;
        if (window.lucide) window.lucide.createIcons();
        return;
    }

    filtered.forEach(item => {
        const card = document.createElement('div');
        card.className = "bg-white rounded-2xl p-6 shadow-sm border border-slate-100 flex flex-col justify-between transition-card";
        
        // Garante que temos uma chave válida (firebaseKey ou ID alternativo limpo)
        const itemId = item.firebaseKey || ('item_' + item.id);

        let statusClass = item.status === 'Disponível' 
            ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' 
            : 'bg-amber-50 text-amber-700 border border-amber-100';

        let actionButton = '';
        if (window.currentAccount.type === 'donor') {
            actionButton = `
                <button type="button" onclick="removeDonation('${itemId}')" class="text-rose-500 hover:text-rose-700 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer">
                    <i data-lucide="trash-2" class="w-4 h-4"></i> Remover
                </button>`;
        } else {
            actionButton = item.status === 'Disponível' 
                ? `<button type="button" onclick="reserveDonation('${itemId}', '${item.title}')" class="bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-4 py-2 rounded-xl transition shadow-sm flex items-center gap-1.5 cursor-pointer">
                    <i data-lucide="check-circle" class="w-4 h-4"></i> Solicitar Resgate
                   </button>`
                : `<button type="button" onclick="openChat('${itemId}', '${item.title}')" class="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-4 py-2 rounded-xl transition shadow-sm flex items-center gap-1.5 cursor-pointer">
                    <i data-lucide="message-square" class="w-4 h-4"></i> Abrir Chat
                   </button>`;
        }

        card.innerHTML = `
            <div>
                <div class="flex justify-between items-start mb-3">
                    <span class="bg-slate-100 text-slate-700 text-xs font-bold px-2.5 py-1 rounded-lg">${item.qty}</span>
                    <span class="text-xs font-medium text-slate-400">Validade: ${item.date}</span>
                </div>
                <h3 class="font-bold text-slate-900 text-base mb-1.5">${item.title}</h3>
                <p class="text-xs text-slate-500 mb-6 flex items-center gap-1.5 font-medium">
                    <i data-lucide="store" class="w-4 h-4 text-slate-400"></i> ${item.donor}
                </p>
            </div>
            <div class="flex justify-between items-center pt-4 border-t border-slate-100">
                <span class="text-xs font-bold px-2.5 py-1 rounded-lg ${statusClass}">${item.status}</span>
                ${actionButton}
            </div>
        `;
        grid.appendChild(card);
    });
    if (window.lucide) window.lucide.createIcons();
};

window.filterDonations = function() {
    const input = document.getElementById('search-input');
    const query = input ? input.value : '';
    window.renderDonations(query);
};

window.addDonation = function(e) {
    if (e) e.preventDefault();
    const title = document.getElementById('food-title').value;
    const qty = document.getElementById('food-qty').value;
    const date = document.getElementById('food-date').value;

    db.ref('items').push({
        title: title,
        qty: qty,
        date: date,
        donor: window.currentAccount.name,
        status: 'Disponível',
        timestamp: Date.now()
    }).then(() => {
        const form = document.getElementById('donation-form');
        if (form) form.reset();
        alert('Doação cadastrada com sucesso na nuvem!');
    }).catch(err => {
        console.error("Erro ao cadastrar doação:", err);
    });
};

window.removeDonation = function(itemId) {
    db.ref('items/' + itemId).remove();
};

window.reserveDonation = function(itemId, title) {
    db.ref('items/' + itemId).update({ status: 'Reservado' }).then(() => {
        alert(`Resgate do item "${title}" solicitado com sucesso!`);
        window.openChat(itemId, title);
    });
};

// ==========================================
// CHAT EM TEMPO REAL CORRIGIDO
// ==========================================

window.openChat = function(itemId, title) {
    if (!itemId) {
        alert("Erro: ID do item inválido para abrir o chat.");
        return;
    }
    currentChatItemId = itemId;
    const chatTitle = document.getElementById('chat-title');
    if (chatTitle) chatTitle.innerText = title ? `Chat: ${title}` : "Chat de Alinhamento";
    
    const chatModal = document.getElementById('chat-modal');
    if (chatModal) chatModal.classList.remove('hidden');
    
    listenToChat(itemId);
};

window.closeChat = function() {
    const chatModal = document.getElementById('chat-modal');
    if (chatModal) chatModal.classList.add('hidden');
};

window.sendMessage = function(e) {
    if (e) e.preventDefault();
    const input = document.getElementById('chat-input');
    const text = input ? input.value.trim() : '';

    if (!text || !currentChatItemId) {
        console.warn("Mensagem vazia ou chat não selecionado.");
        return;
    }

    // Grava no nó correto correspondente ao ID único do item
    db.ref('chats/' + currentChatItemId).push({
        sender: window.currentAccount.name,
        role: window.currentAccount.roleLabel,
        text: text,
        timestamp: Date.now()
    }).then(() => {
        if (input) input.value = '';
        console.log("Mensagem enviada com sucesso para chats/" + currentChatItemId);
    }).catch(err => {
        console.error("Erro ao enviar mensagem:", err);
    });
};

function listenToChat(itemId) {
    const container = document.getElementById('chat-messages');
    if (!container) return;

    // Remove ouvintes anteriores para evitar duplicações
    db.ref('chats/' + itemId).off();

    db.ref('chats/' + currentChatItemId).on('value', (snapshot) => {
    const container = document.getElementById('chat-messages');
    if (!container) return;

    const data = snapshot.val();
    // CORREÇÃO: Transforma o objeto do Firebase num array seguro (ou array vazio se não houver mensagens)
    const msgs = data ? Object.values(data) : [];

    container.innerHTML = msgs.map(m => {
        const isMe = m.sender === currentDonorName;
        return `
            <div class="flex flex-col ${isMe ? 'items-end' : 'items-start'}">
                <span class="text-[9px] text-slate-400 mb-0.5">${m.sender}</span>
                <div class="${isMe ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-800'} px-3 py-2 rounded-2xl max-w-[80%] font-medium">
                    ${m.text}
                </div>
            </div>`;
    }).join('');
    
    container.scrollTop = container.scrollHeight;
});
}

document.addEventListener("DOMContentLoaded", () => {
    if (window.lucide) window.lucide.createIcons();
});