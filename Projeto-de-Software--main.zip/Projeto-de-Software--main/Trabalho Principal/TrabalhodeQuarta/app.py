import streamlit as st

st.set_page_config(page_title="ConectaDoação", page_icon="🤝", layout="wide")

st.title("🤝 ConectaDoação - Protótipo Python")
st.markdown("Plataforma de gestão de doações de alimentos para combate à fome (ODS 2).")

# Métricas
col1, col2 = st.columns(2)
col1.metric("Doações Ativas", "12", "+2 hoje")
col2.metric("Alimentos Salvos", "340 kg", "+45 kg")

st.divider()

# Formulário de cadastro
st.subheader("📦 Cadastrar Nova Doação")
with st.form("form_doacao"):
    titulo = st.text_input("Título do Alimento (ex: Cesta Básica / Hortifrúti)")
    quantidade = st.text_input("Quantidade / Peso (ex: 15 kg)")
    validade = st.date_input("Data de Validade / Retirada")
    
    enviado = st.form_submit_button("Publicar Doação")
    if enviado:
        st.success(f"Doação de '{titulo}' cadastrada com sucesso!")

st.subheader("📋 Lista de Doações Disponíveis")
st.info("Lote de Hortifrúti (25 kg) - Validade: 15/10/2026 - Doador: Supermercado Bom Preço")
st.info("Pães Frescos do Dia (10 kg) - Validade: 14/10/2026 - Doador: Padaria Pão Dourado")