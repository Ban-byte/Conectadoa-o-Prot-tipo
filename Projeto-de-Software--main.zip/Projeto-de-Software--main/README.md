# 💻 Projeto de Software

Repositório centralizador para as atividades, documentações, diagramas e códigos desenvolvidos no contexto da disciplina/projeto de **Projeto de Software**.

## 🚀 Sobre o Projeto
Este espaço tem como objetivo aplicar conceitos fundamentais de Engenharia de Software, garantindo a manutenibilidade, escalabilidade e robustez do código através de boas práticas de arquitetura e design.

## 🛠️ Tópicos Abordados
- **Engenharia de Requisitos:** Levantamento, especificação e análise.
- **Modelagem UML:** Diagramas de Casos de Uso, Classes, Sequência e Atividades.
- **Arquitetura e Padrões:** Separação de responsabilidades, Design Patterns e princípios SOLID.
- **Controle de Qualidade:** Testes e refatoração contínua.

